package com.model;

public class NewVehicle {
	private String vid;
	private String branchAdminId;
	

}
