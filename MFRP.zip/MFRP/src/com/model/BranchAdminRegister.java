package com.model;

public class BranchAdminRegister {
	
	private String branch_admin_id ;
	private int userId;
	private String branch_location ;
	private String address ;
	private String phone_no;
	private String email_id ;
	private String status;
	public String getBranch_admin_id() {
		return branch_admin_id;
	}
	public void setBranch_admin_id(String branch_admin_id) {
		this.branch_admin_id = branch_admin_id;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getBranch_location() {
		return branch_location;
	}
	public void setBranch_location(String branch_location) {
		this.branch_location = branch_location;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public BranchAdminRegister(String branch_admin_id, int userId,
			String branch_location, String address, String phone_no,
			String email_id, String status) {
		super();
		this.branch_admin_id = branch_admin_id;
		this.userId = userId;
		this.branch_location = branch_location;
		this.address = address;
		this.phone_no = phone_no;
		this.email_id = email_id;
		this.status = status;
	}
	
	public BranchAdminRegister()
	{
		
	}

}
