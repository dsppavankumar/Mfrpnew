package com.model;

public class CustSearch {
	private String  vehicleId;
	//private String branchadminid;
	private String manufactureName;
	private int pricemin;
	private int pricemax;
	private String color;
	private int seatCapacity;
	private String bLocation;
	private int quantity;
	
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}
	public String getManufactureName() {
		return manufactureName;
	}
	public void setManufactureName(String manufactureName) {
		this.manufactureName = manufactureName;
	}
	public int getPricemin() {
		return pricemin;
	}
	public void setPricemin(int pricemin) {
		this.pricemin = pricemin;
	}
	public int getPricemax() {
		return pricemax;
	}
	public void setPricemax(int pricemax) {
		this.pricemax = pricemax;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getSeatCapacity() {
		return seatCapacity;
	}
	public void setSeatCapacity(int seatCapacity) {
		this.seatCapacity = seatCapacity;
	}
	public String getbLocation() {
		return bLocation;
	}
	public void setbLocation(String bLocation) {
		this.bLocation = bLocation;
	}
	
	
	public CustSearch(String vehicleId, 
			String manufactureName, int pricemin, int pricemax, String color,
			int seatCapacity, String bLocation) {
		super();
		this.vehicleId = vehicleId;
		//this.branchadminid = branchadminid;
		this.manufactureName = manufactureName;
		this.pricemin = pricemin;
		this.pricemax = pricemax;
		this.color = color;
		this.seatCapacity = seatCapacity;
		this.bLocation = bLocation;
		//this.quantity = quantity;
	}
	public CustSearch() {
		// TODO Auto-generated constructor stub
	}
	
	
	

}
