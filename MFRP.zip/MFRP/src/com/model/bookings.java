package com.model;

public class bookings {
	private int user_id ; 
	private String vehicle_id ;
	private String status;
	
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getVehicle_id() {
		return vehicle_id;
	}
	public void setVehicle_id(String vehicle_id) {
		this.vehicle_id = vehicle_id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public bookings(int user_id, String vehicle_id, String status) {
		super();
		this.user_id = user_id;
		this.vehicle_id = vehicle_id;
		this.status = status;
	}
	public bookings()
	{
		
	}

}
