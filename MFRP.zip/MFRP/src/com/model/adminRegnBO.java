package com.model;

import java.sql.SQLException;

import com.dao.AdminRegnDAO;
import com.dao.LoginDAO;

public class adminRegnBO {
	
	public boolean loginAdmin(adminRegn var) {
		// TODO Auto-generated method stub
		
		AdminRegnDAO aloginDAO=new AdminRegnDAO();
		boolean result=false;
		
		try {
			result=aloginDAO.loginAdmin(var);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
}
