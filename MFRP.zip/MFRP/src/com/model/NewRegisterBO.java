package com.model;

import java.sql.SQLException;

import com.dao.NewRegisterDAO;

public class NewRegisterBO {
	public boolean newRegisterUser(Luser luser) {
		// TODO Auto-generated method stub
		
		NewRegisterDAO loginDAO=new NewRegisterDAO();
		boolean result=false;
		
		try {
			result=loginDAO.newRegisterUser(luser);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

}
