package com.model;

import java.sql.SQLException;
import java.util.List;

import com.dao.BranchAdminDAO;
import com.dao.CustomerRegDAO;
import com.dao.bookingsDAO;

public class BranchAdminBO {
	
	public boolean insertValues(BranchAdminRegister ob)
	{
		BranchAdminDAO usd = new BranchAdminDAO();
		boolean b = usd.insertBranchAdmin(ob);
		return b;
	}
	public List<BranchAdminRegister> bList () throws SQLException
	{
		BranchAdminDAO usd = new BranchAdminDAO();
		List<BranchAdminRegister> BranchAdminList= usd.fetchBList();
		return BranchAdminList;
		
	}
	public boolean updadebranch(String[] bid) {
		// TODO Auto-generated method stub
		BranchAdminDAO usd = new BranchAdminDAO();
		boolean b=usd.updateBranchAdminStatus(bid);
		return b;
	}
	

}
