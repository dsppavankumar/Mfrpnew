package com.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.CustomerRegister;
import com.util.DbUtil;



public class CustomerRegDAO {
   
public boolean insertCust(CustomerRegister ob)
{
	java.sql.Connection con=null;
	   PreparedStatement p=null;
	   //ResultSet r=null;
   boolean flag=false;
   try {
   con=DbUtil.getConnection();
     System.out.println(con);
      
      
     p=con.prepareStatement("insert into customer values(?,?,?,?,?,?,?,?,?)");
     System.out.println("id ="+generateCId());
        p.setString(1,generateCId());
        p.setInt(2,ob.getUserId() );
            p.setString(3,ob.getCustomerName());
            p.setDate(4,new java.sql.Date(ob.getDOB().getTime()));
            p.setString(5,ob.getAddress());
            p.setString(6,ob.getEmail());
            p.setString(7,ob.getPhoneNo());
            p.setString(8,ob.getOccupation());
            p.setString(9,"Pending");
           
          int  r= p.executeUpdate();
            if(r>0)
            {            	System.out.println("row found");
                  flag=true;
            }
      }
      catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
      }
      catch (SQLException e) {
            System.out.println(e.getMessage());
      }
      return flag;
}
public boolean checkCustomer (int userId) throws SQLException
{
	boolean flag=false;
	
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	
	try
	{
		
		//Luser us=new Luser();
		con=DbUtil.getConnection();
		ps=con.prepareStatement("Select * from customer where user_id=?");
		ps.setInt(1, userId);
		rs=ps.executeQuery();
		if(rs.next())
		{
			//System.out.println("found");
			flag=true;
		}
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	catch(ClassNotFoundException e)
	{
		e.printStackTrace();
	}
	finally
	{
		con.close();
	}
	return flag;
	
}
public String generateCId () throws SQLException
{
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	String finalId = "";
	int count=0;
	int varId=1001;
	try
	{
		
		//Luser us=new Luser();
		con=DbUtil.getConnection();
		ps=con.prepareStatement("Select count(*) from customer");
		
		rs=ps.executeQuery();
		if(rs.next())
		count=rs.getInt(1);
		if(count==0)
			 finalId = "C"+varId;
		else{
			varId=varId+count;
		finalId= "C"+varId;
		}
		

	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	catch(ClassNotFoundException e)
	{
		e.printStackTrace();
	}
	finally
	{
		con.close();
	}
	return finalId;
}
public List<CustomerRegister> fetchCList () throws SQLException
{
	List<CustomerRegister> clist = new ArrayList<>();
	
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	
	try
	{
		
		//Luser us=new Luser();
		con=DbUtil.getConnection();
		ps=con.prepareStatement("Select * from customer where status = 'pending'");
		//ps.setString(1,"pending");
		//rs=ps.executeQuery();
		
		
		rs=ps.executeQuery();
		while(rs.next())
		{
			CustomerRegister csReg=new CustomerRegister();
			csReg.setCustomerId(rs.getString(1));
			csReg.setUserId(rs.getInt(2));
			csReg.setCustomerName(rs.getString(3));
			csReg.setDOB(rs.getDate(4));
			csReg.setAddress(rs.getString(5));
			csReg.setEmail(rs.getString(6));
			csReg.setPhoneNo(rs.getString(7));
			csReg.setOccupation(rs.getString(8));
			csReg.setStatus(rs.getString(9));
			
			clist.add(csReg);
		} 
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	catch(ClassNotFoundException e)
	{
		e.printStackTrace();
	}
	finally
	{
		con.close();
	}
	return clist;
	
} 

public boolean updateCustomerStatus(String cid[])
{
	java.sql.Connection con=null;
	   PreparedStatement p=null;
	   //ResultSet r=null;
	   int res=0;
	   int count=0;
   boolean flag=false;
   try {
   con=DbUtil.getConnection();
     System.out.println(con);
      
      
     p=con.prepareStatement("update customer set status='Approved' where customer_id =?");
     for(String s:cid)
     {
    	 p.setString(1,s);
    	 res=p.executeUpdate();
    	 if(res>0)
    		 count++;
    	 
     }
     if(count==cid.length)
    	 flag=true;
     }
     

   catch(SQLException e)
   {}
   catch(ClassNotFoundException e)
   {}
   return flag;
}
}