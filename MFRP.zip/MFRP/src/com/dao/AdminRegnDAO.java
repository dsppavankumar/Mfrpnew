package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.model.Luser;
import com.model.adminRegn;
import com.util.DbUtil;

public class AdminRegnDAO {
	public boolean loginAdmin(adminRegn auser) throws SQLException {
		// TODO Auto-generated method stub
		
		boolean flag=false;
		
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try
		{
			
			//Luser us=new Luser();
			con=DbUtil.getConnection();
			ps=con.prepareStatement("Select * from admin where adminId=? and password=?");
			ps.setInt(1, auser.getAdminId());
			ps.setString(2, auser.getPassword());
			rs=ps.executeQuery();
			if(rs.next())
			{
				//System.out.println("found");
				flag=true;
				
			}
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		{
			con.close();
		}
		return flag;
	}

}
