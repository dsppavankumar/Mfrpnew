package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.CustSearch;
import com.util.DbUtil;

public class requestStockDAO {

	
	public boolean requestStock(com.model.requestStock ob) {
		// TODO Auto-generated method stub
		
		java.sql.Connection con=null;
		   PreparedStatement p=null;
		   //ResultSet r=null;
	   boolean flag=false;
	   try {
		   con=DbUtil.getConnection();
		     System.out.println(con);
		      
		      
		     p=con.prepareStatement("insert into request_stock values(?,?,?,?,?,?,?)");
		     //System.out.println("id ="+generateCId());
		        p.setString(1,generateSId());
		        p.setString(2, ob.getVid());
		        p.setString(3, ob.getMname());
		        p.setInt(4, ob.getPrice());
		        p.setString(5, ob.getColor());
		        p.setInt(6, ob.getSeatCapacity());
		        p.setString(7, ob.getbLocation());
		           
		          int  r= p.executeUpdate();
		            if(r>0)
		            {            	//System.out.println("row found");
		                  flag=true;
		            }
		      }
		      catch (ClassNotFoundException e) {
		            System.out.println(e.getMessage());
		      }
		      catch (SQLException e) {
		            System.out.println(e.getMessage());
		      }
	   
	   
		return flag;
	}
	public String generateSId () throws SQLException
	{
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String finalId = "";
		int count=0;
		int varId=1001;
		try
		{
			
			//Luser us=new Luser();
			con=DbUtil.getConnection();
			ps=con.prepareStatement("Select count(*) from request_stock");
			
			rs=ps.executeQuery();
			if(rs.next())
			count=rs.getInt(1);
			if(count==0)
				 finalId = "S"+varId;
			else{
				varId=varId+count;
			finalId= "S"+varId;
			}
			

		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		{
			con.close();
		}
		return finalId;
	}
	public List<com.model.requestStock> featchStockReq() throws SQLException {
		// TODO Auto-generated method stub
		List<com.model.requestStock> list = new ArrayList<>();
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		 
		try
		{
			 con=DbUtil.getConnection();
		     System.out.println(con);
		     ps=con.prepareStatement("select * from request_stock");
		    
		     
		     rs=ps.executeQuery();
		     while(rs.next())
		     {
		    	 com.model.requestStock reqst=new com.model.requestStock();
		    	 reqst.setStockId(rs.getString(1));
		    	 reqst.setVid(rs.getString(2));
		    	 reqst.setMname(rs.getString(3));
		    	 reqst.setPrice(rs.getInt(4));
		    	 reqst.setColor(rs.getString(5));
		    	 reqst.setSeatCapacity(rs.getInt(6));
		    	 reqst.setbLocation(rs.getString(7));
		    	 
		    	 list.add(reqst);
		     }
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		{
			con.close();
		}
		
		
		return list;
	}
	public boolean updateRequestStock(String[] stid) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag=false;
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String vid=null;
		boolean u=false, d=false;
		int res=0;
		try
		{
			
			 con=DbUtil.getConnection();
			 //List<String> list = new ArrayList<>();
			// List<String> list2 = new ArrayList<>();
			 ps=con.prepareStatement("select * from request_stock where stock_id=?");
		    for(int i=0;i<stid.length;i++)
		    {
		    	  ps.setString(1,stid[i]);
		     rs=ps.executeQuery();
		     while(rs.next())
		     {
		    	// String vid=rs.getString(2);
		    	  // list.add(vid);
		    	  // String branch=rs.getString(7);
		    	  // list2.add(branch);
		    	  vid=rs.getString(2);
		    	  u=updateStock(vid);
		     }
		     deletEntry(stid[i]);
		     res++;
		    }
		    if(res==stid.length)
		    	flag=true;
		    
		    
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		{
			con.close();
		}
		
		
		return flag;
	}

	
public boolean updateStock(String vid) {
		// TODO Auto-generated method stub
	Connection con=null;
	PreparedStatement p=null;
	ResultSet rs=null;
	boolean flag=false;
	   try {
	   con=DbUtil.getConnection();
	     System.out.println(con);
	      
	      
	     p=con.prepareStatement("update vehicle_search set stock=stock+25 where vehicle_id=?;");
	     p.setString(1,vid);
	     p.executeUpdate();
	     flag=true;
	     /*for(String s:vid)
	     {
	    	 p.setString(2,s);
	    	 res=p.executeUpdate();
	    	 if(res>0)
	    		 count++;
	    	 
	     }
	     if(count==vid.length)
	    	 flag=true;
	     deductStockInVehicle(vid, var);
	     }*/
	     
	   }
	   catch(SQLException e)
	   {}
	   catch(ClassNotFoundException e)
	   {}
	  return flag;
		
	}
public boolean deletEntry(String stid) throws SQLException
{
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	boolean flag=false;
	try
	{
		
		
		con=DbUtil.getConnection();
		
		ps=con.prepareStatement("delete from request_stock where stock_id=?");
		
		ps.setString(1,stid);
		ps.executeUpdate();
		flag=true;
	     
		

	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	catch(ClassNotFoundException e)
	{
		e.printStackTrace();
	}
	finally
	{
		con.close();
	}
	return flag;
}
}
