package com.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.BranchAdminRegister;
import com.model.CustomerRegister;
import com.model.bookings;
import com.util.DbUtil;



public class BranchAdminDAO {
   
public boolean insertBranchAdmin(BranchAdminRegister ob)
{
	java.sql.Connection con=null;
	   PreparedStatement p=null;
	   //ResultSet r=null;
   boolean flag=false;
   try {
   con=DbUtil.getConnection();
     System.out.println(con);
      
      
     p=con.prepareStatement("insert into branch_admin values(?,?,?,?,?,?,?)");
        p.setString(1,generateBId());
        p.setInt(2,ob.getUserId());
            p.setString(3,ob.getBranch_location());
            p.setString(4,ob.getAddress());
            p.setString(5,ob.getPhone_no());
            p.setString(6,ob.getEmail_id());
            p.setString(7,"Pending");
            
          int  r= p.executeUpdate();
            if(r>0)
            {            	System.out.println("row found");
                  flag=true;
            }
      }
      catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
      }
      catch (SQLException e) {
            System.out.println(e.getMessage());
      }
      return flag;
}
public boolean checkCustomer (int userId) throws SQLException
{
	boolean flag=false;
	
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	
	try
	{
		
		//Luser us=new Luser();
		con=DbUtil.getConnection();
		ps=con.prepareStatement("Select * from branch_admin where user_id=?");
		ps.setInt(1, userId);
		rs=ps.executeQuery();
		if(rs.next())
		{
			//System.out.println("found");
			flag=true;
		}
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	catch(ClassNotFoundException e)
	{
		e.printStackTrace();
	}
	finally
	{
		con.close();
	}
	return flag;
	
}
public String generateBId () throws SQLException
{
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	String finalId = "";
	int count=0;
	int varId=1001;
	try
	{
		
		//Luser us=new Luser();
		con=DbUtil.getConnection();
		ps=con.prepareStatement("Select count(*) from customer");
		
		rs=ps.executeQuery();
		if(rs.next())
		count=rs.getInt(1);
		if(count==0)
			 finalId = "B"+varId;
		else{
			varId=varId+count;
		finalId= "B"+varId;
		}
		

	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	catch(ClassNotFoundException e)
	{
		e.printStackTrace();
	}
	finally
	{
		con.close();
	}
	return finalId;
}

public List<BranchAdminRegister> fetchBList() throws SQLException {
	// TODO Auto-generated method stub
List<BranchAdminRegister> blist = new ArrayList<>();
	
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	
	try
	{
		
		//Luser us=new Luser();
		con=DbUtil.getConnection();
		ps=con.prepareStatement("Select * from branch_admin where status = 'pending'");
		//ps.setString(1,"pending");
		rs=ps.executeQuery();
		
		
		rs=ps.executeQuery();
		while(rs.next())
		{
			BranchAdminRegister baReg=new BranchAdminRegister();
			/*csReg.setCustomerId(rs.getString(1));
			csReg.setUserId(rs.getInt(2));
			csReg.setCustomerName(rs.getString(3));
			csReg.setDOB(rs.getDate(4));
			csReg.setAddress(rs.getString(5));
			csReg.setEmail(rs.getString(6));
			csReg.setPhoneNo(rs.getString(7));
			csReg.setOccupation(rs.getString(8));
			csReg.setStatus(rs.getString(9));*/
			baReg.setBranch_admin_id(rs.getString(1));
			baReg.setUserId(rs.getInt(2));
			baReg.setBranch_location(rs.getString(3));
			baReg.setAddress(rs.getString(4));
			baReg.setPhone_no(rs.getString(5));
			baReg.setEmail_id(rs.getString(6));
			baReg.setStatus(rs.getString(7));
			
			blist.add(baReg);
		} 
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	catch(ClassNotFoundException e)
	{
		e.printStackTrace();
	}
	finally
	{
		con.close();
	}
	return blist;
	
}
public boolean updateBranchAdminStatus(String bid[])
{
	java.sql.Connection con=null;
	   PreparedStatement p=null;
	   //ResultSet r=null;
	   int res=0;
	   int count=0;
   boolean flag=false;
   try {
   con=DbUtil.getConnection();
     System.out.println(con);
      
      
     p=con.prepareStatement("update branch_admin set status='Approved' where branch_admin_id =?");
     for(String s:bid)
     {
    	 p.setString(1,s);
    	 res=p.executeUpdate();
    	 if(res>0)
    		 count++;
    	 
     }
     if(count==bid.length)
    	 flag=true;
     }
     

   catch(SQLException e)
   {}
   catch(ClassNotFoundException e)
   {}
   return flag;
}
public void updateStock(List<bookings> blist) {
	// TODO Auto-generated method stub
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	int res=0,count=0;
	try {
		   con=DbUtil.getConnection();
		     System.out.println(con);
		      
		      
		     ps=con.prepareStatement("update vehicle_search set stock=stock-1 where vehicle_id =?");
		     for(bookings s:blist)
		     {
		    	 ps.setString(1,s.getVehicle_id());
		    	 res=ps.executeUpdate();
		    	 
		     }
		     
	}   

		   catch(SQLException e)
		   {}
		   catch(ClassNotFoundException e)
		   {}


}
}