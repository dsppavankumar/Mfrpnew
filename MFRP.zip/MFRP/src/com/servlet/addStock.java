package com.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.bookings;
import com.model.bookingsBO;
import com.model.requestStock;
import com.model.requestStockBO;

/**
 * Servlet implementation class addStock
 */
public class addStock extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addStock() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		List<requestStock> list= new ArrayList<>();
		//HttpSession session=request.getSession();
		//int var=(int) session.getAttribute("uid");
		RequestDispatcher dispatcher=null;
		requestStockBO rbo = new requestStockBO();
		try {
			 list  =rbo.featchStockReq();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(list!=null)
		{
			for(requestStock q:list)
			{
				System.out.println(q.getVid()+" "+ q.getStockId());
			}
			request.setAttribute("vehiclePendingLst", list);
			dispatcher=request.getRequestDispatcher("requestStockList.jsp");
			dispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session=request.getSession();
		RequestDispatcher dispatcher=null;
		String stid[]=request.getParameterValues("stid");
		requestStockBO rcbo = new requestStockBO();
		boolean flag = false;
		try {
			flag = rcbo.updateRequestStock(stid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		if(flag)
		{
			dispatcher=request.getRequestDispatcher("stockAdded.jsp");
			dispatcher.forward(request, response);
		}
		
	}

}
