package com.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.CustSearch;
import com.model.CustSearchBO;
import com.model.bookings;
import com.model.bookingsBO;

/**
 * Servlet implementation class CustomerHomeServlet
 */
public class CustomerHomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerHomeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.setContentType("text/html");
		RequestDispatcher req=null;
		String vehicleId=null;
		String mname=request.getParameter("mname");
		int pricemin=Integer.parseInt(request.getParameter("pricemin"));
		int pricemax=Integer.parseInt(request.getParameter("pricemax"));
		String color=request.getParameter("color");
		int seatCapacity=Integer.parseInt(request.getParameter("seatCapacity"));
		String bloc=request.getParameter("blocation");
		String branchadminid=null;
		
		CustSearch cs=new CustSearch(vehicleId,mname,pricemin,pricemax,
				color,seatCapacity,bloc);
		//System.out.println(mname);
		//System.out.println(pricemin);
		//System.out.println(pricemax);
		//System.out.println(seatCapacity);
		CustSearchBO csbo=new CustSearchBO();
		List<CustSearch> vLst=new ArrayList<>();
			try {
				vLst=csbo.vehicleSearch(cs);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println(vLst.isEmpty());
			if(vLst.isEmpty())
			{
				req=request.getRequestDispatcher("failVehicleList.jsp");
				req.forward(request, response);
				
			}
			else if(vLst!=null)
			{
				
				
				request.setAttribute("vehicleList", vLst);
				req=request.getRequestDispatcher("vehicleList.jsp");
				req.forward(request, response);
			}
		
	}

	/*
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		RequestDispatcher dispatcher=null;
		String vid[]=request.getParameterValues("vid");
		int var =  (int) session.getAttribute("uid");
		System.out.println(var);
		List<bookings> blist = new ArrayList<>();
		for(int i=0;i<vid.length;i++)
		{
			bookings book = new bookings();
			book.setUser_id(var);
			book.setVehicle_id(vid[i]);
			blist.add(book);
		}
		bookingsBO bookbo = new bookingsBO();
		boolean flag = bookbo.insertBooking(blist);
		
		
		
		if(flag)
		{
			dispatcher=request.getRequestDispatcher("customerHome.jsp");
			dispatcher.forward(request, response);
		}
	}

}
