package com.servlet;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BranchAdminRegister;
import com.model.BranchAdminBO;
import com.util.DbUtil;


/**
 * Servlet implementation class RegisterServlet
 */
public class BranchAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BranchAdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		BranchAdminRegister user = new BranchAdminRegister();
		response.setContentType("text/html");
		//RequestDispatcher req=null;
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher=null;
		
		HttpSession session=request.getSession();
		
		int userid=(int)session.getAttribute("uid");
		user.setBranch_admin_id(null);
		
		user.setUserId(userid);
		 user.setBranch_location(request.getParameter("blocation"));
		//user.setBranch_admin_id(request.getParameter("bAdminId"));		 
		  user.setAddress(request.getParameter("address"));
		  user.setEmail_id(request.getParameter("emailId"));
		  user.setPhone_no(request.getParameter("phoneNo"));
		  
		  user.setStatus(null);
		  BranchAdminBO csdo = new BranchAdminBO();
		  boolean result = csdo.insertValues(user);
		  
		  if(result)
			{
				out.print("welcome from Login");
				dispatcher=request.getRequestDispatcher("branchAdminHome.jsp");
				dispatcher.forward(request, response);
			}
		  else
		  {
			  request.setAttribute("message","Invalid username/password");
			  dispatcher=request.getRequestDispatcher("login.jsp");
			  dispatcher.forward(request, response);
			
		  }
		  
		  
	}
	
}
